# Version 1.0.3 - 08/25/2021
- Fix issue loading list reviews on frontend because the module Lof_CustomerAvatar was not setup.
- Fix issue when submit new reviews, the email was not sent then show exception error.
- Fix issue when edit review gallery images on backends.
- Update little css code to style for review listing on frontend.

# Version 1.0.5 - 02/16/2022
- Refactor code
- Fix bugs and compatible for magento 2.4.0 - 2.4.x
- Fully support REST API
- Upgrade database tables add some columns
- Refactor list reviews
- Update email templates

# Version 1.0.6 - 02/16/2022
- Refactor REST API
- Add new column updated_at for table "lof_review_reply"
